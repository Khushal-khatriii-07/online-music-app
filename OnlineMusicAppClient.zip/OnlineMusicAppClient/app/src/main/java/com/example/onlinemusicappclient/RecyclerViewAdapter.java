package com.example.onlinemusicappclient;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.onlinemusicappclient.Model.Uploads;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter {

    public RecyclerViewAdapter(Context applicationContext, List<Uploads> uploads) {
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

}
